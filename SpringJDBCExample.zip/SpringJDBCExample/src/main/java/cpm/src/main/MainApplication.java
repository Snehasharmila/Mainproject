package cpm.src.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.src.dao.BookDao;
import com.src.model.Book;

public class MainApplication {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		BookDao b1=(BookDao) context.getBean("bookdao");
		
		/*int status=b1.saveBook(new Book(12,"Html","Stanley",1000,"Technical",4));
		if(status>0)
		{
			System.out.println("Values Inserted Successfully");
		}
		else
		{
			System.out.println("Unable to Insert");
		}
		int statuss=b1.saveBook(new Book(14,"Html","Stanley",1000,"Technical",4));
		if(statuss>0)
		{
			System.out.println("Values Inserted Successfully");
		}
		else
		{
			System.out.println("Unable to Insert");
		}
		
		int status1=b1.updateBook(new Book(12,"Java","Richard",600,"Technical",4));
		if(status1>0)
		{
			System.out.println("Values Updated Successfully");
		}
		else
		{
			System.out.println("Unable to Update");
		}
		
		int status3=b1.deleteBook(new Book(12));
		if(status3>0)
		{
			System.out.println("Values Deleted Successfully");
		}
		else
		{
			System.out.println("Unable to Delete");
		}*/
		
		List<Book> e2=b1.displayAllBook();
		for(Book b:e2)
		{
			System.out.println(b);
		}
	}

}
