package com.src.model;

public class Book {
	
	private int bookid;
	private String bookname;
	private String bookauthor;
	private int bookcost;
	private String booktype;
	private int bookedition;
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getBookauthor() {
		return bookauthor;
	}
	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}
	public int getBookcost() {
		return bookcost;
	}
	public void setBookcost(int bookcost) {
		this.bookcost = bookcost;
	}
	public String getBooktype() {
		return booktype;
	}
	public void setBooktype(String booktype) {
		this.booktype = booktype;
	}
	public int getBookedition() {
		return bookedition;
	}
	public void setBookedition(int bookedition) {
		this.bookedition = bookedition;
	}
	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", bookname=" + bookname + ", bookauthor=" + bookauthor + ", bookcost="
				+ bookcost + ", booktype=" + booktype + ", bookedition=" + bookedition + "]";
	}
	public Book(int bookid, String bookname, String bookauthor, int bookcost, String booktype, int bookedition) {
		super();
		this.bookid = bookid;
		this.bookname = bookname;
		this.bookauthor = bookauthor;
		this.bookcost = bookcost;
		this.booktype = booktype;
		this.bookedition = bookedition;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book(int i) {
		// TODO Auto-generated constructor stub
		this.bookid=i;
	}
	
	
	

}
