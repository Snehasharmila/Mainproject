package com.src.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.src.model.Book;

public class BookDao implements BookDaoInterface {

	private JdbcTemplate jdbctemp;
	
	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

	@Override
	public int saveBook(Book b) {
		String query="insert into Book values("+b.getBookid()+",'"+b.getBookname()+"','"+b.getBookauthor()+"',"+b.getBookcost()+",'"+b.getBooktype()+"',"+b.getBookedition()+")";
		return jdbctemp.update(query);
	}

	@Override
	public int updateBook(Book b) {
		String query="update book set bookname='"+b.getBookname()+"',bookauthor='"+b.getBookauthor()+"',bookcost="+b.getBookcost()+",booktype='"+b.getBooktype()+"',bookedition="+b.getBookedition()+" where bookid="+b.getBookid();
		return jdbctemp.update(query);
	}

	@Override
	public int deleteBook(Book b) {
		String query="delete from book where bookid="+b.getBookid();
		return jdbctemp.update(query);
	}

	@Override
	public List<Book> displayAllBook() {
		return jdbctemp.query("select * from book",(rs,row)->
		{
			Book b= new Book();
			b.setBookid(rs.getInt(1));
			b.setBookname(rs.getString(2));
			b.setBookauthor(rs.getString(3));
			b.setBookcost(rs.getInt(4));
			b.setBooktype(rs.getString(5));
			b.setBookedition(rs.getInt(6));
			return b;
		});
		
		
	}
	

}
